
# VGA

A VGA (Video Graphics Array) signal generation from an FPGA (Field-Programmable Gate Array) involves creating and controlling the necessary timing signals and pixel data output to produce a standard VGA video signal. The FPGA is programmed to generate horizontal and vertical synchronization pulses, back-porch, front-porch, and active video signals according to VGA timing specifications. It then uses a memory buffer or a graphical rendering algorithm to store or generate the pixel data, which is converted into analog RGB signals that drive the monitor or display device. This process synchronizes the display of images or graphics on the screen by following the VGA standard, allowing for high-quality video output from the FPGA.

## Instructions

This implementation uses three switches on the FPGA from 0-2 to control the inputs to the tbird. It 0 is the right signal, 1 is the hazard signal 2 is the left signal, and push button 3 is the clear signal.